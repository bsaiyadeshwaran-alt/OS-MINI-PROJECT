def scan(requests, head, disk_size=200):
    left = [r for r in requests if r < head]
    right = [r for r in requests if r >= head]

    left.sort(reverse=True)
    right.sort()

    sequence = [head] + right + [disk_size-1] + left
    seek_time = 0

    for i in range(len(sequence) - 1):
        seek_time += abs(sequence[i+1] - sequence[i])

    return {"sequence": sequence, "seek_time": seek_time}
