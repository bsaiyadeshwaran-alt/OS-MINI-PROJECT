def sstf(requests, head):
    requests = requests.copy()
    sequence = [head]
    seek_time = 0
    current = head

    while requests:
        closest = min(requests, key=lambda x: abs(x - current))
        seek_time += abs(current - closest)
        current = closest
        sequence.append(current)
        requests.remove(closest)

    return {"sequence": sequence, "seek_time": seek_time}
