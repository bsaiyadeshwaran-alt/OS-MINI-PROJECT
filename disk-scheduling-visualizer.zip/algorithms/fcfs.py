def fcfs(requests, head):
    sequence = [head] + requests
    seek_time = 0

    for i in range(len(sequence) - 1):
        seek_time += abs(sequence[i+1] - sequence[i])

    return {"sequence": sequence, "seek_time": seek_time}
