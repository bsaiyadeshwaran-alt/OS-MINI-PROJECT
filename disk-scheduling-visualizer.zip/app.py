from flask import Flask, render_template, request, jsonify
from algorithms.fcfs import fcfs
from algorithms.sstf import sstf
from algorithms.scan import scan
from algorithms.look import look
from utils.parser import parse_input

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/calculate', methods=['POST'])
def calculate():
    data = request.json

    requests = parse_input(data['requests'])
    head = int(data['head'])
    algo = data['algorithm']

    if algo == "FCFS":
        result = fcfs(requests, head)
    elif algo == "SSTF":
        result = sstf(requests, head)
    elif algo == "SCAN":
        result = scan(requests, head, disk_size=200)
    elif algo == "LOOK":
        result = look(requests, head)
    else:
        return jsonify({"error": "Invalid Algorithm"})

    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)
