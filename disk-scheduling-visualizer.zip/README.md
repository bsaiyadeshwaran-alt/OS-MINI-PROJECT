# Disk Scheduling Algorithm Visualizer

## How to Run
pip install -r requirements.txt
python app.py
