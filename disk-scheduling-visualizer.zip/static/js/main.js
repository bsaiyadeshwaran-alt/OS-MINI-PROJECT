function calculate() {
    const requests = document.getElementById("requests").value;
    const head = document.getElementById("head").value;
    const algorithm = document.getElementById("algorithm").value;

    fetch('/calculate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requests, head, algorithm })
    })
    .then(res => res.json())
    .then(data => {
        document.getElementById("seekTime").innerText =
            "Total Seek Time: " + data.seek_time;

        drawChart(data.sequence);
    });
}
