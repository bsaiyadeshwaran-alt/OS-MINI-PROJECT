let chart;

function drawChart(sequence) {
    const ctx = document.getElementById('chart').getContext('2d');

    if (chart) chart.destroy();

    chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: sequence.map((_, i) => i),
            datasets: [{
                label: 'Head Movement',
                data: sequence,
                fill: false,
                borderColor: 'blue',
                tension: 0.1
            }]
        }
    });
}
